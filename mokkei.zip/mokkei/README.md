# Parcel template project

## Usage

develop
```text
npm run dev
```

deploy
```text
npm run build
```
